evidence(draw_hand(player2,[ace, king, queen, ace])).
evidence(coin(tails)).
