evidence(winner(player1)).
evidence(cheater).
